package org.btm.BankApp;

public class BankFactory {
   public static ICard getBank(String type) {
	   if(type.equalsIgnoreCase("sbi")) {
		   return new SbiImpl();
	   }
	   else if(type.equalsIgnoreCase("pnb")) {
		   return new PnbImpl();
	   }
	   else {
		   System.out.println("no bank found");
	   }
	   return null;
   }
}
