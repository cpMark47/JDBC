package org.btm.BankApp;

import java.util.Scanner;

public class TestBank {
 public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter the type of card");
   String type=sc.next();
   sc.close();
   ICard ic=BankFactory.getBank(type);
   if(ic!=null) {
	   ic.swipe();
   }
}
}
