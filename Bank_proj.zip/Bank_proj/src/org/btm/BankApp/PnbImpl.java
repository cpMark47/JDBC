package org.btm.BankApp;

public class PnbImpl implements ICard {
    @Override
    public void swipe() {
    	System.out.println("PNB card swiped");
    	
    }
		
	}
   

