package org.btm.BankApp;

public class SbiImpl implements ICard{
	@Override
	public void swipe() {
		System.out.println("SBI card swiped");
		
	}

}
