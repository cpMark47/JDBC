package org.btm.BankApp;

public interface ICard {
   void swipe();
}
