package org.btm.lightApp;

public class TubeLightImpl implements ISwitch{
	@Override
	public void sOn() {
		System.out.println("Tubelight is on");
	}
	@Override
	public void sOff() {
        System.out.println("Tubelight is on");
	}
}
