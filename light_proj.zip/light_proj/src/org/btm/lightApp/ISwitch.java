package org.btm.lightApp;

public interface ISwitch {
      void sOn();
      void sOff();
}
