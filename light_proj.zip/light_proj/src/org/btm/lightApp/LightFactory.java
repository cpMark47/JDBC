package org.btm.lightApp;

public class LightFactory {
   public static ISwitch getLight(String type) {
	   if(type.equalsIgnoreCase("tubelight")) {
		   return new TubeLightImpl();
	   }
	   else if(type.equalsIgnoreCase("ledlight")) {
		   return new LedLightImpl();
	   }
	   else{
		 System.out.println("no lights found");  
	   }
	   return null;
   }
}
