package org.btm.lightApp;

public class LedLightImpl implements ISwitch {
	@Override
	public void sOn() {
		System.out.println("Ledlight is on");
	}
	@Override
	public void sOff() {
        System.out.println("ledlight is on");
	}
}
